package com.e3i3.moduerp.buystock.model.dao;

public class BuyStockOutDaoImpl {

}
