package com.e3i3.moduerp.quality.model.service;

import java.util.List;
import com.e3i3.moduerp.quality.model.dto.QualityControlDTO;

public interface QualityControlService {
    List<QualityControlDTO> getAllQualityControls();
}
