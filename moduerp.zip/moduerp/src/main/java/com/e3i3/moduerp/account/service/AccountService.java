package com.e3i3.moduerp.account.service;

import java.util.List;
import com.e3i3.moduerp.account.model.dto.AccountDTO;

public interface AccountService {
    List<AccountDTO> getAllAccounts();
}
