package com.e3i3.moduerp.order.model.dto;

public class OrderDTO {

}
