package com.e3i3.moduerp.faqattachment.controller;

public class FaqattachmentController {

}
