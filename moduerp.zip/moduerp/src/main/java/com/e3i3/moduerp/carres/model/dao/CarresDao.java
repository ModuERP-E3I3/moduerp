package com.e3i3.moduerp.carres.model.dao;

import java.util.List;

import com.e3i3.moduerp.carres.model.dto.CarresDto;

public interface CarresDao {
	List<CarresDto> getAllCarres();
}
