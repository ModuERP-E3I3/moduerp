package com.e3i3.moduerp.carres.model.service;

import java.util.List;

import com.e3i3.moduerp.carres.model.dto.CarresDto;

public interface CarresService {
	List<CarresDto> getAllCarres();

}
