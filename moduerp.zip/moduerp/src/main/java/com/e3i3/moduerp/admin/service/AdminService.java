package com.e3i3.moduerp.admin.service;

import java.util.List;
import com.e3i3.moduerp.admin.model.dto.AdminDTO;

public interface AdminService {
    List<AdminDTO> getAllAdmins();
}
