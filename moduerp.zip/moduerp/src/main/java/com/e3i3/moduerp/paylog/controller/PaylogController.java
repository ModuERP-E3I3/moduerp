package com.e3i3.moduerp.paylog.controller;

public class PaylogController {

}
