package com.e3i3.moduerp.buystock.DAO;

public class BuyStockDao {

}
