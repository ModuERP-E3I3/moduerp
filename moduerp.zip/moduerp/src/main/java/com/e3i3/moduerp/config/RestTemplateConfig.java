package com.e3i3.moduerp.config;

public class RestTemplateConfig {

}
