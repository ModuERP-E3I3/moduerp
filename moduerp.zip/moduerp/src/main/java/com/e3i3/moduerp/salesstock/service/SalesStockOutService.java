package com.e3i3.moduerp.salesstock.service;

import java.util.List;
import com.e3i3.moduerp.salesstock.model.dto.SalesStockOutDTO;

public interface SalesStockOutService {
    List<SalesStockOutDTO> getAllSalesStockOuts();
}
