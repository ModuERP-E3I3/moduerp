package com.e3i3.moduerp.buystock.DTO;

public class BuyStockInDto {

}
