package com.e3i3.moduerp.employee.model.dao;

import java.util.List;

public interface EmployeeSalesDAO {
    List<String> selectEmployeeNamesByBizNumber(String bizNumber);

    String selectEmployeeNameByUuid(String uuid);
}
