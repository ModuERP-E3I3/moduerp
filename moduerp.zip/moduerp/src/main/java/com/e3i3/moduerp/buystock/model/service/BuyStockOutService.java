package com.e3i3.moduerp.buystock.model.service;

import java.util.List;

import com.e3i3.moduerp.buystock.model.dto.BuyStockOutDTO;

public interface BuyStockOutService {
	List<BuyStockOutDTO> getAllBuyStockOuts();

}
