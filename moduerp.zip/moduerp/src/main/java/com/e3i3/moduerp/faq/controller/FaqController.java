package com.e3i3.moduerp.faq.controller;

public class FaqController {

}
